@extends('layouts2.app')
@section('titulo','DashBoard')

@include('forms.dashBoard.dashBoard')

 