<footer class="page-footer footer-fixed blue darken-1" style="background-color: #3949ab; z-index: 3">
        <div class="footer-copyright">
          <div class="container">
            <span class="right">
              Desarrollado por <a class="grey-text text-lighten-4" href="http://innovatec.me">
              <b style="color: #fafafa; font-style: normal;">INNOVA</b>TEC</a>
            </span>

            
            
          </div>
        </div>
      </footer>