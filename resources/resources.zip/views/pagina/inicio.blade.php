@extends('pagina.layouts.app')

@section('inicio')
	 @include('pagina.layouts.partials.carrusel')  
@endsection

@section('main-content')
	@include('pagina.nosotros')
@endsection