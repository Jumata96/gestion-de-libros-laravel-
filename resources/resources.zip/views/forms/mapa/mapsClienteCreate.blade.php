
{{--  modal  --}}
<div id="modalCreate1" class="modal " style="height: 100%; width: 60%">


	<iframe src="{{url('/mapa') }}" title=" " style="width: 110%; height:750px;">
	</iframe>
	 


			
			 
			 
</div>

