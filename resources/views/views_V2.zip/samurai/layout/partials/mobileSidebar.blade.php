<div id="s5_responsive_mobile_sidebar_inner1" class="s5_responsive_mobile_sidebar_light">
    <div id="s5_responsive_mobile_sidebar_inner2">
       
       <div style="clear:both"></div> 
       <div id="s5_responsive_mobile_sidebar_menu_wrap">
          <!--<ul class="menu">-->
          <h3 class=''><span><a  class="s5_mobile_sidebar_active"   href="{{ url('/index2') }}" >INICIO</a></span></h3>
          <h3 class=''><span><a  class="s5_mobile_sidebar_active"   href="{{ url('/index2') }}" >NOSOTROS</a></span></h3>
          <h3 class=''><span><a  class="s5_mobile_sidebar_active"   href="{{ url('/index2') }}" >SERVICIOS</a></span></h3>
          <h3 class=''><span><a  class="s5_mobile_sidebar_active"   href="{{ url('/index2') }}" >TEAMS</a></span></h3>
          <h3 class=''><span><a  class="s5_mobile_sidebar_active"   href="{{ url('/contactanos') }}" >CONTACTANOS</a></span></h3>
 
          <!--</ul>-->
       </div> 
    </div>
 </div>