<header id="s5_menu_wrap">
	<div id="s5_menu_wrap_inner" class="s5_wrap">
		<div id="s5_menu_wrap_inner2" style="height: 60px;">
			<div id="s5_logo_wrap" class="s5_logo s5_logo_css" style="margin-top: 1px;">
				<img alt="logo" style="width: 140px; height: 48px !important;" src="{{asset('samurai/templates/fitness_center/images/blanco.png')}}" onclick="window.document.location.href='index-2.html'" />
				<div style="clear:both;"></div>
			</div>
			<nav id="s5_menu_inner" class="s5_wrap_menu" style="height: 60px;">
				<ul id='s5_nav' class='menu'>
					<li   class='active ' style="padding-top: 17px;"><span class='s5_level1_span1'><span class='s5_level1_span2'><a  href="{{ url('/index') }}"><span>Inicio</span></a></span></span></li>
					<li   class=' '  style="padding-top: 17px;" >
						<span class='s5_level1_span1'><span class='s5_level1_span2'><a href='javascript:;'><span onclick='window.document.location.href="javascript:;"'>Nosotros</span></a></span></span>
						<ul style='float:left;'>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/contact-us.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/contact-us.html"'>Contact Us</span></a></span></li>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/search.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/search.html"'>Search</span></a></span></li>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/wrapper.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/wrapper.html"'>Wrapper</span></a></span></li>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/about-us.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/about-us.html"'>About Us</span></a></span></li>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/news.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/news.html"'>Category Blog</span></a></span></li>
							<li class=''><span class='S5_submenu_item'><a href='index.php/pages/our-services.html'><span class='s5_sub_a_span' onclick='window.document.location.href="index.php/pages/our-services.html"'>Our Services</span></a></span></li>
						</ul>
					</li>
					<li   class=' '  style="padding-top: 17px;" >
						<span class='s5_level1_span1'><span class='s5_level1_span2'><a href='javascript:;'><span onclick='window.document.location.href="javascript:;"'>Servicios</span></a></span></span>
					</li>
					<li   class=' '  style="padding-top: 17px;" >
						<span class='s5_level1_span1'><span class='s5_level1_span2'><a href='javascript:;'><span onclick='window.document.location.href="javascript:;"'>Teams</span></a></span></span>
					</li>
					<li   class=' '  style="padding-top: 17px;" >
						<span class='s5_level1_span1'><span class='s5_level1_span2'><a  href="{{ url('/contactanos') }}"><span >Contactanos</span></a></span></span>
					</li>
				</ul>
			</nav>
			<div id="s5_pos_custom_1" style="padding-top: 17px; margin: 0px;">
				<div class="moduletable">
					<div class="custom"  >
						<a class="social_icon ion-social-facebook" target="_blank" href="http://www.facebook.com/#"></a>
						<a class="social_icon ion-social-twitter" href="javascript:;"></a> 
						<a class="social_icon ion-social-googleplus" href="javascript:;"></a> 
						<a class="social_icon ion-social-linkedin" href="javascript:;"></a> 
					</div>
				</div>
				<div style="clear:both; height:0px"></div>
			</div>
			<div style="clear:both;height:0px"></div>
		</div>
	</div>
</header>