<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Prueba de envio de mensajes desde Laravel</title>
</head>
<body>
    <p>Hola! Esta es una prueba de envio desde laravel.</p>
</body>
</html>