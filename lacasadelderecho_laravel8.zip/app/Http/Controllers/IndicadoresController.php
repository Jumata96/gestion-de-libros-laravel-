<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Collection as Collection;
use DB;
use Validator;
use Auth;

class IndicadoresController extends Controller
{
    public function getTotalPedidos(){

    }
}
